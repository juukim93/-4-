// purgecss.config.js
module.exports = {
  content: ['../board/Purchase.jsp'], // CSS를 분석할 HTML 파일 및 JavaScript 파일 경로
  css: ['../css/argon-dashboard.css'], // 대상 CSS 파일
  output: '../path/to/output.css', // 출력 경로를 설정
  // 다양한 옵션 설정
};